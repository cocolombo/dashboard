#!/bin/bash

cd /home/nimzo/PARA/1-Projets/python/startme
/home/nimzo/PARA/1-Projets/python/startme/.venv/bin/python manage.py runserver 0.0.0.0:8000
